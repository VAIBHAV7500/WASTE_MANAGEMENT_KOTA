package com.example.abhinay.user_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private TextView mNameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase=FirebaseDatabase.getInstance().getReference().child("Name");


        mDatabase.addValueEventListener(new ValueEventListener()){
            @Override
                    public void onDataChange(DataSnapshot datasnapshot){
                String name=dataSnapshot().getValue().toString();
                if(name=='')

            }
        }
    }
}
